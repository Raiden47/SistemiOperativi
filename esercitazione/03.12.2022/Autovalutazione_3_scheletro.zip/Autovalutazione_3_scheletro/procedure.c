#include <stdio.h>
#include <unistd.h>

#include "header.h"

void inizializza_vettore(VettoreProdCons * p) {

}

void produci(VettoreProdCons * p, int valore) {

}

int consuma(VettoreProdCons * p) {

}

void rimuovi_vettore(VettoreProdCons * p) {

}


void inizializza_buffer(BufferMutuaEsclusione * p) {

}

void aggiorna_buffer(BufferMutuaEsclusione * p, int valore) {

    // TODO: incrementa il contenuto del buffer

}

int stampa_valore(BufferMutuaEsclusione * p) {

    // TODO: Attendi il completamento di NUM_CONS consumazioni e stampa valore

}

void rimuovi_buffer(BufferMutuaEsclusione * p) {

}
