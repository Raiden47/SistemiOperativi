#include "stack.h"
#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>

void *Inserisci(void * s)
{

	int i;
	Elem v;
    
    Stack * stack = (Stack *) s;

	for(i=0; i<4; i++) {
		v = rand() % 11;
		StackPush(stack, v);
		printf("Inserimento: %d\n", v);
		sleep(1);
	}

	// Terminazione thread
}


void *Preleva(void * s)
{

	int i;
	Elem v1, v2;

    Stack * stack = (Stack *) s;
    
	for(i=0; i<10; i++) {
		v1=StackPop(stack);
		printf("Prelievo: %d\n", v1);

		v2=StackPop(stack);
		printf("Prelievo: %d\n", v2);

		printf("Somma: %d\n", v1+v2);

		sleep(3);
	}

	// Terminazione thread

}


int main(int argc, char *argv[])
{
	// Istanziamo i thread

	int i;

	srand(time(NULL));

	// Istanziamo lo stack


	// Attributi thread

	for(i=0; i<5; i++) {
		// Creazione thread per l'inserimento
	}

	// Creazione thread per il prelievo


	for(i=0; i<6; i++) {
		// Attesa terminazione thread
	}


	// Rimozione stack

}

