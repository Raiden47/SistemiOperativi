#include "stack.h"

#include <stdlib.h>

void StackInit(Stack * s, int dim) {
	
}


void StackRemove(Stack * s) {
	
}

void StackPush(Stack * s, Elem e) {
	
}


Elem StackPop(Stack * s) {

	int elemento;

	

	return elemento;
}

int StackSize(Stack * s) {
	int size;

	

	return size;
}
